import { useState, useMemo } from "react";
import "./App.css";

const ARTICLES = [
  {
    id: 1,
    title: "Understanding the difference between grid-template and grid-auto",
    date: "Oct 09, 2018",
    text:
      "With all the new properties related to CSS Grid Layout, one of the distinctions that always confused me was the difference between the grid-template-* and grid-auto-* properties. Specifically the difference between grid-template-rows/columns and grid-auto-rows/columns. Although I knew they were to d..."
  },
  {
    id: 2,
    title: "Recreating the GitHub Contribution Graph with CSS Grid Layout",
    date: "",
    text:
      ""
  }
];

function escapeRegExp(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function highlight(text, query) {
  if (!query) return text;
  const safe = escapeRegExp(query);
  const regex = new RegExp(`(${safe})`, "gi");
  const parts = text.split(regex);
  return parts.map((part, i) =>
    i % 2 === 1 ? <mark key={i}>{part}</mark> : <span key={i}>{part}</span>
  );
}

export default function App() {
  const [query, setQuery] = useState("grid");

  const filtered = useMemo(() => {
    if (!query.trim()) return ARTICLES;
    const q = query.toLowerCase();
    return ARTICLES.filter(
      a =>
        a.title.toLowerCase().includes(q) ||
        a.text.toLowerCase().includes(q)
    );
  }, [query]);

  return (
    <div className="page">
      <div className="content">
        <h1 className="search-title">Search</h1>

        <div className="search-input-wrapper">
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            className="search-input"
            placeholder="grid"
          />
          {query && (
            <button className="clear-btn" onClick={() => setQuery("")}>
              ×
            </button>
          )}
        </div>

        <div className="count">
          <strong>{filtered.length} posts</strong> were found.
        </div>

        {filtered.map(a => (
          <div key={a.id} className="article">
            <span className="article-title">{highlight(a.title, query)}</span>
            <div className="article-date">{a.date}</div>
            <div className="article-text">{highlight(a.text, query)}</div>
          </div>
        ))}
      </div>

      <div className="sidebar">
  <p><strong>bitsofcode.</strong> Articles on Frontend Development. All articles are written by <a href="#">Ire Aderinokun</a>, Frontend Developer and User Interface Designer.</p>

  <button className="follow-btn">
    Follow @ireaderinokun
  </button>

  <span className="followers">19.1K followers</span>
</div>

    </div>
  );
}
